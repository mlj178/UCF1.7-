vis/  ——  游戏内 Ctrl+E 的导出落点

这里本来会堆满历次扫描的 JSON。2026-11-16 已经清理过一次：
  * 整理后的「原始地图数据集」在  ../maps/           （编号 + 中文名，一张图一份）
  * 只读还原点在              ../backup/maps_original_20261116/
  * 其余历史导出归档在        ../backup/vis_history_20261116_122127/

以后进游戏按 Ctrl+E（或开 Ctrl+Shift+X 采集模式，进图自动导出），文件会重新出现在这里。
整理命令：
    python ../tools/organize_maps.py --archive

（这个说明文件不会被 organize_maps.py 搬走。）
